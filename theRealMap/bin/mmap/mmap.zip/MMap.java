/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mmap;

import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;

/**
 *
 * @author gbjohnson
 */
public class MMap {

    /**
     * @param args the command line arguments
     * @throws java.text.ParseException
     * @throws java.io.IOException
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws ParseException, IOException, InterruptedException {
        // This can easily be stored in an external file probably. 
        String[][] Machines
                = {{"Laptop_B", "LAM213-149874"},
                {"Workstation_A", "LAM213-156907"},
                {"Workstation_B", "LAM213-146828"},
                {"Workstation_C", "LAM213-145595"},
                {"Workstation_D", "LAM213-146902"},
                {"Workstation_E", "LAM213-148102"},
                {"Workstation_F", "LAM213-148661"},
                {"Workstation_G", "LAM213-146979"},
                {"Workstation_H", "LAM213-145158"},
                {"Workstation_I", "LAM213-148164"},
                {"Workstation_J", "LAM213-148693"},
                {"Workstation_K", "LAM213-148697"},
                {"Workstation_L", "LAM213-145621"},
                {"Workstation_M", "LAM213-158150"},
                {"Workstation_N", "LAM213-148265"},
                {"Workstation_O", "LAM213-156983"},
                {"Workstation_P", "LAM213-156916"},
                {"Workstation_Q", "LAM213-158137"},
                {"Workstation_R", "LAM213-154638"},
                {"Workstation_S", "LAM213-148679"},
                {"Workstation_T", "LAM213-148677"},
                {"Workstation_U", "LAM213-148681"},
                {"Workstation_V", "LAM213-156428"},
                {"Workstation_W", "LAM213-156909"},
                {"Workstation_X", "LAM213-148675"},
                {"Workstation_Y", "LAM215-156971"},
                {"Workstation_Z", "LAM215-156922"}};

        for (String[] Machine : Machines) {
            QueryMachine qm = new QueryMachine();
            qm.getMachineQuery(Machine[1]);

            // Make sure to handle zero responces as machine being free.
            for (int i = 0; i < qm.getNumSessions(); i++) {

                // qm.getSessionArray(i) this gets an array of a user session.
                // This will need to be broken up, and pumped into firebase. 
                // the array returns ALL data from each line of the query program.
                // The first item in every array is the machine name. 
                // Look at QueryParser.java for more info.
                System.out.println(Arrays.toString(qm.getSessionArray(i)));
            }
        }
    }
}
